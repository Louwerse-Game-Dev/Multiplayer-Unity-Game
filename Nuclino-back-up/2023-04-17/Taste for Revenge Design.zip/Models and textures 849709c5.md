This is the place where we should show all art used in the game. Pixel art, animations, the game icon etc. Feel free to edit this page however you like.\
Maybe keep the example / placeholder text and pictures untill we have something to replace it with.

---

## Some random example pictures as inspiration of things to show on this page:

![7000bb3b-7428-4ca8-9e1d-c54e5f63c2ce.png](files/15864773-128f-4536-998f-42dcab4958e7/7000bb3b-7428-4ca8-9e1d-c54e5f63c2ce.png)

![00bc37b9-8cd1-46c9-9f61-761858f1bd96.png](files/3ca528cd-6f7c-4305-a1d1-2667317807b0/00bc37b9-8cd1-46c9-9f61-761858f1bd96.png)

![3eca96b5-0302-4a21-bfff-647dfe2ad520.png](files/9f12771a-4237-4c29-a5fa-ec776725ff17/3eca96b5-0302-4a21-bfff-647dfe2ad520.png)

![8cd214c1-bb13-43c9-a40b-e14454a49507.png](files/81f79b47-ec21-43e1-ac75-e659f418d767/8cd214c1-bb13-43c9-a40b-e14454a49507.png)

<br>
