In order to create a game that is aesthetically pleasing i think it is a great idea to find a fitting color palette.\
This color palette should be based on / inspired by the story and the game setting over all. Meaning that it should fit the locations the players will visit but also fit the feeling the player should get by experiencing the story.

Check out the following pages: [Style and inspiration](<Style and inspiration fa93367b.md>) & [🏞️ Game setting](<🏞️ Game setting 1e21c7f3.md>)

Using a color palette with too few or too many colors might complicate the process of making pixel art. So as a rule of thumb, we should try to find a color palette with an amount of colors somewhere between 8 and 20 colors.

Below this we can keep track of a few palettes to choose from;

# Indecision palette

![6423d12b-0f05-4f44-9558-fc5b187d8895.png](files/6111d6e3-ceb7-41e0-b44c-68ba33823ca8/6423d12b-0f05-4f44-9558-fc5b187d8895.png)

[Indecision Palette](https://lospec.com/palette-list/indecision "Indecision Palette")

I think this palette will fit the RPG + medieval theme, not super bright colors, but still enough color and brightness so it does not feel to dark and dull. It also has a bit of that Stardew Valley feel to it, color wise.

This might be a lot of colors to use however, over complicating the progress of making art for the game.

# Example title, replace me

![63678f9a-73e2-46c4-bac2-cc8e600babcb.png](files/32406723-3653-4e32-99b4-cebbf37d50c6/63678f9a-73e2-46c4-bac2-cc8e600babcb.png)

[Link, replace me](https://lospec.com/palette-list "Palette List")

Explanation, replace me
