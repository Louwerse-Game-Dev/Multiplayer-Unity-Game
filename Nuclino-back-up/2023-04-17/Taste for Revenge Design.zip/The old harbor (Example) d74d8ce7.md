![location.jpg](files/fa83e43b-e3ae-43fd-9629-d674971d8df4/location.jpg)# General descriptionThe old harbor is a place bustling with activity. It's always full of noise: the shouts of fishermen auctioning their fish, the loud thuds of crates being loaded off the boats, the cries of hungry seagulls. [The fish market](<The fish market 449c2c8e.md>) is located at the heart of the harbor.In [Level 1: Prologue](<Level 1_ Prologue 6e31f9ca.md>), [The protagonist](<The protagonist 20bed4c8.md>) reaches the harbor after surviving a shipwreck and being rescued by a fisherman. ...## Inspiration[](https://www.youtube.com/watch?v=t0AmfPQMs4k)# Levels that use this area- [Level 1: Prologue](<Level 1_ Prologue 6e31f9ca.md>)
- [Level 2: Tutorial](<Level 2_ Tutorial daf4359a.md>)
- ...# Connections to other areas- [The fish market](<The fish market 449c2c8e.md>) is located in the old harbor area.
- The old harbor is to the south of [The imperial capital](<The imperial capital 2bbc21da.md>).
- ...
