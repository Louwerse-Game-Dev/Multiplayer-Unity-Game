# Final asset

[*Upload*](https://help.nuclino.com/6bace612-use-file-attachments "Use file attachments") *the asset here after getting it approved by the art director.*

# Tasks

- [x] Sketch the initial concept [@Name](https://help.nuclino.com/988f802d-mention-a-team-member "Mention a team member") <2022-12-06>
- [x] Create the illustration [@Name](https://help.nuclino.com/988f802d-mention-a-team-member "Mention a team member") <2022-12-12>
- [ ] Get feedback from the team [@Everyone](https://help.nuclino.com/353324ea-use-groups "Use groups") <2023-01-10>
- [ ] Create the final textures [@Name](https://help.nuclino.com/988f802d-mention-a-team-member "Mention a team member") <2023-01-17>
- [ ] Final review and approval by art director [@Name](https://help.nuclino.com/988f802d-mention-a-team-member "Mention a team member") <2023-01-24>

# Concept sketch

![14724275574\_73804fea27\_o.jpg](files/1ded39e4-6cea-4b54-afc6-f7d52f04f28d/14724275574_73804fea27_o.jpg)
Temple (initial concept sketch)

# Illustration

![14726344312\_9068fa17e6\_o.jpg](files/cf7ce47d-1e73-48e7-b586-d5484ed3d287/14726344312_9068fa17e6_o.jpg)
Temple (colorized illustration)

## Inspiration

![inspiration-image2.jpg](files/2fd4e6eb-c659-4cdc-91ca-9a046332a5fc/inspiration-image2.jpg)
![inspiration-image1.jpg](files/eb5faa2d-57e4-462b-84f9-41e0153504d0/inspiration-image1.jpg)
![inspiration-image3.jpg](files/305ff028-881e-4774-8b96-1deb2eaceb7d/inspiration-image3.jpg)

## Feedback

- ...
- ...
- ...

# Model & texture

...

<br>

---

*Artwork credit:* [*Ryzom*](https://www.flickr.com/photos/ryzom/ "Ryzom MMORPG")
