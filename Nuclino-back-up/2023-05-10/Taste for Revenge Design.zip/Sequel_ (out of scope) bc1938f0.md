This is a list of idea's we should not try to add to the game, to prevent the game never getting finished. We should however keep track of these in case we ever want to add something new or create a sequel after the game (or an MVP) is done.

- Crafting system
