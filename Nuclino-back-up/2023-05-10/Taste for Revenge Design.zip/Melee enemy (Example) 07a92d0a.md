# General description

...

## Inspiration

Based on character: [Emperor Muriel VII (Example)](<Emperor Muriel VII (Example) dd9c9bfd.md>)

...

## In game story / lore bit

...

# Stats

## Abilities

...

## Strengths

...

## Weaknesses

...

# Location(s)

- ???

# Level(s)

- ???

# Loot table

## Enemy specific

| Name                                           | Amount | Rate |
| ---------------------------------------------- | ------ | ---- |
| [👒 Example hat](<👒 Example hat ca6baa37.md>) | 1      | 100% |

## General

| Name | Amount | Rate |
| ---- | ------ | ---- |
|      |        |      |

<br>
