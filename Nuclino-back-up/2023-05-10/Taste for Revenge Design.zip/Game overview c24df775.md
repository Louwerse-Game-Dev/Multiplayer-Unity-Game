*Placeholder image:*

![be2b0f0b-1d32-47d3-a8cd-4c77743316d5.png](files/e47e1590-b80e-46d3-aad2-821d5247841b/be2b0f0b-1d32-47d3-a8cd-4c77743316d5.png)

# Working title

Taste for Revenge

# Elevator pitch

We're developing a rogue-like coop game set in a medieval fantasy world, with some RPG aspects. Its gameplay is somewhat story-driven but mostly combat based, inspired by the gameplay of games like ["Nine Parchments"](https://store.steampowered.com/app/471550/Nine_Parchments/ "Save 75% on Nine Parchments on Steam"), ["Enter the Gungeon"](https://store.steampowered.com/app/311690/Enter_the_Gungeon/ "Enter the Gungeon on Steam") and ["Wizard of Legend"](https://store.steampowered.com/app/445980/Wizard_of_Legend/ "Wizard of Legend on Steam"). In this game the weapons and armor you have equipped will heavily impact how you play the game. In addition to each weapon having its own auto attack, each weapon and every armor item you can equip also has one specific ability/skill you can use in combat. Switching any of these items for another will most likely result in you having to rethink your way of playing the game.

# Concept

## Overview

- **Genre:** Rogue-like / RPG / Action
- **Target audience:**
  - **Age:** 15-30
  - **Gender:** Male/Female
- **Monetization:** One time purchase.
- **Platforms & system requirements:** &#x20;
  - PC
  - [Requirements...](https://answers.unity.com/questions/711400/how-to-determine-hardware-requirements-for-game-ma.html) to do

## Theme and setting

### ['Voorproever'](https://historianet.nl/maatschappij/vorsten/de-vreemdste-dienaren-van-de-koning-geselknaap-en-billenveger#:~:text=Nam%20gif%20in%3A%20Voorproever%20speelt%20met%20de%20dood "De vreemdste dienaren van de koning: Geselknaap en billenveger") / ['food taster'](https://en.wikipedia.org/wiki/Food_taster "Food taster - Wikipedia")

"The task was usually entrusted to a noble or a soldier who had shown extraordinary loyalty to the king."

Taste for Revenge is a (funny) roguelike coop game set in a medieval fantasy world. The player takes on the role of a soldier who is also a food taster for the king. Until one day the king gets poisoned and dies. \
This happens after the player had tasted the food the king ate, but because the player does not die after eating the same food, he gets accused of poisoning the king. \
The player escapes the castle (tutorial?) and goes on an adventure to find and reveal the real killer to prove his innocence.

(The real killer is a crazy, not all to smart, but very funny cook who reveals himself early on to the player, making fun of the player during his encounters)

The player does this together with his fellow soldiers who do not believe he is guilty (that help him escape in the tutorial). This are the other players.\
The player(s) get to explore procedurally generated parts of the world, moving from place to place, running away from the angry soldiers and bounty hunters (etc.), that are trying to lock you up or kill you. Along the way you learn that this world contains more dangers (like monsters/creatures) you need to survive, while you also discover how and why the king was poisoned.

The path towards your next goal in each part of the story is procedurally generated, you have to go from room to room, fighting waves of enemies (In the style of ["Hades"](https://store.steampowered.com/app/1145360/Hades/ "Hades on Steam"), [example video](https://youtu.be/Zpo2UgLkLxo?t=144 "The First 15 Minutes of Hades Gameplay")). At the end or half way through this you encounter one or more bosses to fight. Often these bosses are send by the cook who actually poisoned the king.

Learn more about the [Locations](<Locations d8e9eb60.md>), [Story](<Story 870e5287.md>), and [Characters](<Characters ccb6e305.md>) of the game.

<br>

*(to do: add something to the story to explain how the roguelike aspect of the game works? For when you die and restart, but also for when you 'complete' the game and restart, different stories for this?)*

*(to do: at some point in the story it is explained that the cook actually gave you the antidote for the poison used before you ate the food)*

(to do: in some part of the story it is explained that the cook hated you and the king for some stupid and maybe funny reason, but a reason that can be related to by the player(s), so they might feel some pity for him)

*(to do: maybe move some of  this to [🏞️ Game setting](<🏞️ Game setting 1e21c7f3.md>) and replace this with a better summery or continue writing the full story in [Main story](<Main story 257d4ce4.md>)?)*

# Project scope

## Our team

- **Dev:** [Wilco Louwerse](https://app.nuclino.com/users/b6c993fa-7356-4198-9ef9-92b997c7e5d3?mId=Yse2z7LD)
- **Design:** [Wilco Louwerse](https://app.nuclino.com/users/b6c993fa-7356-4198-9ef9-92b997c7e5d3?mId=LJoNFX3j)
- **Art: @Anoek & [Wilco Louwerse](https://app.nuclino.com/users/b6c993fa-7356-4198-9ef9-92b997c7e5d3?mId=FT8uvcrZ)**

## Timeline

- 01/mei/23 → 22/mei/23\
  Do some Unity tutorials - Setup basic player controls - Setup basic main menu - Setup multiplayer
  <br>
- 22/mei/23 → 12/jun/23

  Dungeon Generator - Setup MiniMap - Start with first art and animations
  <br>
- 12/jun/23 → 03/jul/23

  Setup combat - Setup basic enemy behaviour - Create enemies and first Boss
  <br>
- 03/jul/23 → 24/jul/23

  Setup basic quest system - Start making a tutorial - Improve menu feel and functionalities
  <br>
- 24/jul/23 → 14/aug/23

  Setup sound effects and music - Create some basic sound effects and music - Settings & Pause menu - Setup basic Achievement system
  <br>
- 14/aug/23 → 04/sep/23

  Setup items & loot system - Setup inventory & equipement - Setup stats & improve art + animations
  <br>
- 04/sep/23 → 25/sep/23

  Setup abilities - Start adding more particle effects - Improve game feel & environment
  <br>
- 25/sep/23 → 16/okt/23

  Improve art, animations & particle effects - Start adding light, glow & other image effects - Improve on existing functionalities - Add more functionalities & game content...
  <br>
- 16/okt/23 → → →&#x20;

  Play testing & bug fixes - release the game on steam?
