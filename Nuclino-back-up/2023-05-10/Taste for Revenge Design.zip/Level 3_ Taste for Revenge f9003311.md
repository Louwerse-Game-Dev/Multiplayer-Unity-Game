# Synopsis

...

# Objectives

...

# Location(s)

- ???

# Enemies

- ???

# Level walkthrough

...
