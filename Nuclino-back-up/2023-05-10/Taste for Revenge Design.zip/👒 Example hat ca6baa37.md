# General description

- 👒 Head

...

## Inspiration

Hat of: [Emperor Muriel VII (Example)](<Emperor Muriel VII (Example) dd9c9bfd.md>)

...

## In game story / lore bit

...

# Stats

## Ability

...

## Strengths

...

## Weaknesses

...

# Dropped by

| Enemy                                                        | Amount | Rate |
| ------------------------------------------------------------ | ------ | ---- |
| [Melee enemy (Example)](<Melee enemy (Example) 07a92d0a.md>) | 1      | 100% |

<br>
