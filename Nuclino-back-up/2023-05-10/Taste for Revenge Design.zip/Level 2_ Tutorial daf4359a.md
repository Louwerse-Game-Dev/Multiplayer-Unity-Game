# Synopsis

During this level the player(s) are escaping the castle, during this they will learn the basics of how to play the game. The goal of this level is to teach the player(s) the basics while also progressing the story, this combined should make it feel like a good and not an annoying 'tutorial'. Maybe in a way the player(s) do not even notice that it actually is a tutorial.

<br>

to do: create a better title for this level.

# Objectives

...

# Location(s)

- [The castle](<The castle 2bbc21da.md>)

# Enemies

- ???

# Level walkthrough

The player(s) just got out of the throne room...
