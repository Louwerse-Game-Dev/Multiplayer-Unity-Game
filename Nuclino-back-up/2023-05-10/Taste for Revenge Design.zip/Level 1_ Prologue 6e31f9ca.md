# Synopsis

This Prologue is mostly a cinematic and maybe some short movement / interaction for the player(s).

# Objectives

...

# Location(s)

- [The castle](<The castle 2bbc21da.md>) - [The throne room](<The throne room 1465e3e7.md>)

# Enemies

- ???

# Level walkthrough

The level starts of with some sort of cinematic, in pixel art?

First the camera moves over a long table with lots of food on it and people eating and drinking. There is a feast going on in the throneroom of the king.

The camera ends on the king and the player (and some more important people?) at the head of the table, the king in his throne. The player tastes the food before the king can eat. The king eats the food, dies. But you stay alive. Someone in the room accuses you of killing the king. The player has to escape the castle....

<br>

<br>

<br>

<br>

<br>

<br>

<br>

<br>
