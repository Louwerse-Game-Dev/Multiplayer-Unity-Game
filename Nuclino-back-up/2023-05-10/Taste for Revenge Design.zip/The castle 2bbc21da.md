# General description

This is the starting area of the story, where it all begins.

...

## Inspiration

...

# Levels that use this area

- [Level 1: Prologue](<Level 1_ Prologue 6e31f9ca.md>)
- [Level 2: Tutorial](<Level 2_ Tutorial daf4359a.md>)

# Connections to other areas

- ???

# Enemies in this area

- ???
